﻿using DataManager;
namespace BusinessManager.Repositpry
{
 public   class RegisterMember : Interface.BusinessManager.IRegisterMember
    {
        private Interface.DataManager.IRegisterMember IRegisterMember { get; set; }
        public RegisterMember(Interface.DataManager.IRegisterMember datarepository)
        {
            IRegisterMember = datarepository;
        }
        public void InsertMember(MemberRegister member)
        {
           IRegisterMember.InsertMember(member);
         }
    }
}
