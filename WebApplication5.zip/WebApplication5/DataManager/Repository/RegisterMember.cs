﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManager.Repository
{
    public class RegisterMember : Interface.DataManager.IRegisterMember
    {
        public RegisterMember(){}

            public void InsertMember(MemberRegister memberData)

        {
            using (var context = new gymMembershipEntities())

            {
                context.MasterInsert(memberData.name, memberData.Address, memberData.date);
            }
        }
            
            }
}
