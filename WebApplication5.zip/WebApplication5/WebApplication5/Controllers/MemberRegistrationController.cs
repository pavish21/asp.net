﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataManager;
namespace WebApplication5.Controllers
{
    public class MemberRegistrationController : Controller
    {
        private Interface.BusinessManager.IRegisterMember registerMember { get; set; }

        public MemberRegistrationController(Interface.BusinessManager.IRegisterMember registerMemberManager)
        {
            registerMember = registerMemberManager;
        }


        // GET: MemberRegistration
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult SaveData()
        {
            MemberRegister mem= new MemberRegister();
            return View(mem);
        }
        [HttpPost]
        public ActionResult SaveData(MemberRegister member)
        {

            
            registerMember.InsertMember(member);
            //gymMembershipEntities ge = new gymMembershipEntities();
            //ge.MasterInsert(member.name,member.Address,member.date);
           return View("Index");
        }

    }
}