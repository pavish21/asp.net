using System.Web.Mvc;
using Unity;
using Unity.Mvc5;

namespace WebApplication5
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();
            
            // register all your components with the container here
            // it is NOT necessary to register your controllers
            
         container.RegisterType<Interface.BusinessManager.IRegisterMember,BusinessManager.Repositpry.RegisterMember>();
            container.RegisterType<Interface.DataManager.IRegisterMember, DataManager.Repository.RegisterMember>();

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}