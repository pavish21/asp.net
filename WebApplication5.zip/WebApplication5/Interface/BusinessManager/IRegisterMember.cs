﻿using DataManager;

namespace Interface.BusinessManager
{
   public interface IRegisterMember
    {
        void InsertMember(MemberRegister  member);
    }
}
