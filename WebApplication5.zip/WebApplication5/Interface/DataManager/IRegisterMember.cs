﻿using DataManager;
namespace Interface.DataManager
{
   public  interface IRegisterMember
    {
        void InsertMember(MemberRegister member);
    }
}
